class MyClass
{
  public:

    // Constructor
    MyClass( int InputOne );

    // A Method
    int TestMethod( int InputTwo );

  private:

    // A private member variable
    int m_storedValue;

// SUPER IMPORTANT
// Don't forget the semicolon below
};
